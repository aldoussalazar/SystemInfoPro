========================================================================
                           READ THIS FIRST!
                    SYSTEM INFORMATION PRO v1.0
========================================================================

WELCOME!
--------
Thank you for downloading System Information Pro! This folder contains
everything you need to use our system diagnostic tool.

WHAT'S IN THIS FOLDER?
----------------------
This distribution package contains three main components:

1.  Installer\        - Full installation version (recommended)
2.  Portable\         - No-installation version
3.  Documentation\    - User guides and resources

WHICH VERSION SHOULD I USE?
---------------------------

  FOR MOST USERS: Use the INSTALLER version
   • Proper Windows integration
   • Start Menu shortcuts
   • Easy uninstallation
   • Desktop shortcut option
   • Recommended for regular use

  FOR TECHNICIANS OR TEMPORARY USE: Use the PORTABLE version
   • No installation needed
   • Run from USB drives
   • Works without admin rights
   • Leaves no system traces
   • Perfect for troubleshooting

QUICK START
-----------

OPTION A: INSTALLER VERSION
1. Go to the Installer\ folder
2. Double-click SystemInfoProSetup.exe
3. Follow the installation wizard
4. Launch from Start Menu

OPTION B: PORTABLE VERSION  
1. Go to the Portable\ folder
3. Double-click SystemInfoPro.exe
4. Use the menu to select options

DOCUMENTATION
-------------
Check the  Documentation\ folder for:

• User_Manual.txt      - Complete user guide
• Quick_Start_Guide.txt - Get started quickly
• LICENSE.txt          - License agreement
• Release_Notes.txt    - Version information

FEATURES
--------
✓ Complete system hardware inventory
✓ Memory and storage analysis  
✓ Network configuration details
✓ Software environment scan
✓ Professional report generation
✓ JSON export support
✓ User-friendly interface
✓ No external dependencies

REPORTS
-------
All reports are saved to:
• Documents\SystemInfo Reports\

You can:
• Generate detailed text reports
• Create JSON reports for programmers
• View system summary on screen
• Open reports folder directly

TROUBLESHOOTING
---------------
If you have issues:

1. Try running as Administrator
2. Check your antivirus isn't blocking the program
3. Ensure you have write permissions to Documents folder
4. For installer issues, try the portable version
5. Check Documentation folder for more help

SUPPORT
-------
Email: aldoussalazar0@gmail.com

Please include:
• Which version you're using (Installer/Portable)
• Windows version
• What you were trying to do
• Any error messages

LICENSE
-------
This software is free for personal, educational, and
non-commercial use. See LICENSE.txt for complete terms.

VERSION: 1.0.0
RELEASE DATE: December 2025

========================================================================
                      ENJOY USING SYSTEM INFORMATION PRO!
========================================================================